insert into Categorias (Categoria_ID, Nombre) values ('606', 'Kanoodle');
insert into Categorias (Categoria_ID, Nombre) values ('5350', 'Rhybox');
insert into Categorias (Categoria_ID, Nombre) values ('1703', 'Jaxspan');
insert into Categorias (Categoria_ID, Nombre) values ('820', 'Zoomdog');
insert into Categorias (Categoria_ID, Nombre) values ('734', 'Divape');
insert into Categorias (Categoria_ID, Nombre) values ('16', 'Realbuzz');
insert into Categorias (Categoria_ID, Nombre) values ('963', 'Trudoo');
insert into Categorias (Categoria_ID, Nombre) values ('82', 'Topicshots');
insert into Categorias (Categoria_ID, Nombre) values ('5160', 'Jaxnation');
insert into Categorias (Categoria_ID, Nombre) values ('3365', 'Blogspan');

select * from categorias