insert into libros (ISBN, Tiulo) values ('170', 'Santos');
insert into libros (ISBN, Tiulo) values ('50', 'Look Who''s Talking');
insert into libros (ISBN, Tiulo) values ('58', 'California Dreamin'' (Nesfarsit)');
insert into libros (ISBN, Tiulo) values ('226', 'Teenage Dirtbag');
insert into libros (ISBN, Tiulo) values ('4557', 'Spin');
insert into libros (ISBN, Tiulo) values ('5951', 'Princess Bride, The');
insert into libros (ISBN, Tiulo) values ('9548', 'Kiki''s Delivery Service (Majo no takkyûbin)');
insert into libros (ISBN, Tiulo) values ('1026', 'Stone of Destiny');
insert into libros (ISBN, Tiulo) values ('680', 'I Spit on Your Grave (Day of the Woman)');
insert into libros (ISBN, Tiulo) values ('240', 'Gleason');


select * from libros