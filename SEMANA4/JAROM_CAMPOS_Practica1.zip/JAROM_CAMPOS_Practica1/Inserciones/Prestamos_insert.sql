insert into Prestamos (Prestamo_ID, Nombre) values ('539959232', 'Plantaginaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('406630267', 'Asteraceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('569025449', 'Poaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('220236365', 'Boraginaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('771936201', 'Cyperaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('312329231', 'Cactaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('512390510', 'Fabaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('619494590', 'Araliaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('877754629', 'Scrophulariaceae');
insert into Prestamos (Prestamo_ID, Nombre) values ('154981123', 'Lichinaceae');

select * from prestamos