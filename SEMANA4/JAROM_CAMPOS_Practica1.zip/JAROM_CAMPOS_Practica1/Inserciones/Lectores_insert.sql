insert into Lectores (Lector_ID, Nombre) values (1995, 'HVAC');
insert into Lectores (Lector_ID, Nombre) values (1996, 'Welder');
insert into Lectores (Lector_ID, Nombre) values (1990, 'Concrete Finisher');
insert into Lectores (Lector_ID, Nombre) values (2006, 'Refridgeration');
insert into Lectores (Lector_ID, Nombre) values (2012, 'Stucco Mason');
insert into Lectores (Lector_ID, Nombre) values (2008, 'Plasterers');
insert into Lectores (Lector_ID, Nombre) values (1993, 'Cement Mason');
insert into Lectores (Lector_ID, Nombre) values (2011, 'Sheet Metal Worker');
insert into Lectores (Lector_ID, Nombre) values (2004, 'Laborer');
insert into Lectores (Lector_ID, Nombre) values (1997, 'Boilermaker');

select * from lectores