create table Lectores(
    Lector_ID serial primary key,
    Nombre varchar(40) not null
)