create table Autores(
    Autor_ID serial primary key,
    Nombre varchar(60) not null
)