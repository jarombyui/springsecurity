create table libros(
    ISBN serial primary key,
    Tiulo varchar(40) not null
)