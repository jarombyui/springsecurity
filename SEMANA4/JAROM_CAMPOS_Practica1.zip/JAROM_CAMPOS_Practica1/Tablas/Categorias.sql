create table Categorias(
    Categoria_ID serial primary key,
    Nombre varchar
)