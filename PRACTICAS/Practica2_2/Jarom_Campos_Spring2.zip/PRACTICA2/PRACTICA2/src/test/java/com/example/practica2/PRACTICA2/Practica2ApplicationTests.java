package com.example.practica2.PRACTICA2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
