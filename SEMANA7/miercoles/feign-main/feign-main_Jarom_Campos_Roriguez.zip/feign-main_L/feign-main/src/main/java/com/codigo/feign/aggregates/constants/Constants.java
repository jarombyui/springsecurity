package com.codigo.feign.aggregates.constants;

public class Constants {
    public static final Integer CODE_SUCCESS = 200;
    public static final Integer CODE_ERROR = 400;
    public static final String MESS_SUCCESS="Ejecución correcta";
    public static final String MESS_ERROR="Error en la Ejecución";
}

